const sql = require('mssql');

// === CONFIGURACIONES DE LOS SERVIDORES ===
const servers = {
  corporativo: {
    user: 'sa',
    password: 'Albatroz1205$',
    server: "JAMI1205\\NODO_CORPORATIVO",
    database: 'CORPORATIVO',
    options: {
      encrypt: false,
      trustServerCertificate: true
    }
  },

  sanjose: {
    user: 'sa',
    password: 'Albatroz1205$',
    server: "JAMI1205\\NODO_SANJOSE",
    database: 'SANJOSE',
    options: {
      encrypt: false,
      trustServerCertificate: true
    }
  },

  limon: {
    user: 'sa',
    password: 'Albatroz1205$',
    server: "JAMI1205\\NODO_LIMON",
    database: 'LIMON',
    options: {
      encrypt: false,
      trustServerCertificate: true
    }
  }
};

// === FUNCIÓN PARA CONECTARSE ===
async function connect(serverName) {
  const config = servers[serverName];

  if (!config) {
    throw new Error(` El servidor '${serverName}' no existe en db.js`);
  }

  try {
    console.log(`Conectando a SQL Server (${serverName})...`);
    await sql.connect(config);
    console.log(`✔ Conectado correctamente a ${serverName}`);
  } catch (error) {
    console.error(` Error al conectar a ${serverName}:`, error);
    throw error;
  }
}

module.exports = { sql, connect };
